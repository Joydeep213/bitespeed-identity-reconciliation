const express = require('express');
const bodyParser = require('body-parser');
const Contact = require('./models/contact');

const app = express();
app.use(bodyParser.json());

app.post('/identify', async (req, res) => {
    const { email, phoneNumber } = req.body;
    let contacts = [];
    if (email) {
        contacts = await Contact.findAll({ where: { email } });
    }
    if (phoneNumber) {
        contacts = contacts.concat(await Contact.findAll({ where: { phoneNumber } }));
    }

    let primaryContact = null;
    if (contacts.length > 0) {
        primaryContact = contacts.find(c => c.linkPrecedence === 'primary');
        if (!primaryContact) {
            primaryContact = contacts[0];
        }

        const secondaryContacts = contacts.filter(c => c.id !== primaryContact.id);
        secondaryContacts.forEach(async contact => {
            contact.linkedId = primaryContact.id;
            contact.linkPrecedence = 'secondary';
            await contact.save();
        });
    } else {
        primaryContact = await Contact.create({ email, phoneNumber, linkPrecedence: 'primary' });
    }

    const consolidatedContact = await Contact.findAll({ where: { linkedId: primaryContact.id } });
    const emails = Array.from(new Set(consolidatedContact.map(c => c.email).concat(primaryContact.email).filter(e => e)));
    const phoneNumbers = Array.from(new Set(consolidatedContact.map(c => c.phoneNumber).concat(primaryContact.phoneNumber).filter(p => p)));
    const secondaryContactIds = consolidatedContact.map(c => c.id);

    res.json({
        contact: {
            primaryContactId: primaryContact.id,
            emails,
            phoneNumbers,
            secondaryContactIds,
        },
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
